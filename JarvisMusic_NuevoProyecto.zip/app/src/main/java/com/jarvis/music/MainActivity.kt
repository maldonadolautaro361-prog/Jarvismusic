package com.jarvis.music

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.TimeUnit

data class Song(val title: String, val artist: String, val uri: Uri)

class MainActivity : AppCompatActivity() {
    private val songs = mutableListOf<Song>()
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var player: MediaController? = null
    private lateinit var listContainer: LinearLayout
    private lateinit var nowPlaying: TextView
    private lateinit var timeText: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var playButton: Button
    private val permissionRequest = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        connectPlayer()
        if (hasAudioPermission()) loadSongs()
        else requestAudioPermission()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(0xFF100B1D.toInt())
        }

        val heading = TextView(this).apply {
            text = "♫  JARVIS MUSIC"
            textSize = 26f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 18)
        }
        page.addView(heading)

        val subtitle = TextView(this).apply {
            text = "TU BIBLIOTECA"
            textSize = 13f
            setTextColor(0xFFB9A4FF.toInt())
            setPadding(0, 6, 0, 10)
        }
        page.addView(subtitle)

        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this).apply {
            addView(listContainer)
        }
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val divider = View(this).apply { setBackgroundColor(0xFF3B3150.toInt()) }
        page.addView(divider, LinearLayout.LayoutParams(-1, 1))

        nowPlaying = TextView(this).apply {
            text = "Elegí una canción"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 5)
        }
        page.addView(nowPlaying)

        seekBar = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(0xFF9B7BFF.toInt())
            thumbTintList = android.content.res.ColorStateList.valueOf(0xFFBCA8FF.toInt())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) player?.let {
                        if (it.duration > 0) it.seekTo(it.duration * progress / 1000L)
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        page.addView(seekBar)

        timeText = TextView(this).apply {
            text = "0:00 / 0:00"
            textSize = 13f
            setTextColor(0xFFBEB7C9.toInt())
            gravity = Gravity.CENTER
        }
        page.addView(timeText)

        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        val previous = makeButton("⏮") { player?.seekToPreviousMediaItem() }
        playButton = makeButton("▶") { togglePlayback() }
        val next = makeButton("⏭") { player?.seekToNextMediaItem() }
        controls.addView(previous, LinearLayout.LayoutParams(0, 58, 1f).apply { marginEnd = 5 })
        controls.addView(playButton, LinearLayout.LayoutParams(0, 58, 1.3f).apply { marginStart = 5; marginEnd = 5 })
        controls.addView(next, LinearLayout.LayoutParams(0, 58, 1f).apply { marginStart = 5 })
        page.addView(controls)

        val shuffle = makeButton("⇄  Aleatorio") {
            player?.shuffleModeEnabled = !(player?.shuffleModeEnabled ?: false)
            Toast.makeText(this, if (player?.shuffleModeEnabled == true) "Aleatorio activado" else "Aleatorio desactivado", Toast.LENGTH_SHORT).show()
        }
        page.addView(shuffle, LinearLayout.LayoutParams(-1, 48).apply { topMargin = 8 })

        setContentView(page)
        page.post(object : Runnable {
            override fun run() {
                updatePlaybackInfo()
                page.postDelayed(this, 500)
            }
        })
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF34264D.toInt()))
            setOnClickListener { action() }
        }

    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                player = controllerFuture?.get()
                playButton.text = if (player?.isPlaying == true) "Ⅱ" else "▶"
            } catch (_: Exception) {
                Toast.makeText(this, "No se pudo iniciar el reproductor", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        ActivityCompat.requestPermissions(this, arrayOf(permission), permissionRequest)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == permissionRequest && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            loadSongs()
        } else {
            Toast.makeText(this, "Necesitamos permiso para mostrar tu música", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadSongs() {
        songs.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val cursor: Cursor? = contentResolver.query(collection, projection, selection, null, sort)
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val title = it.getString(titleCol) ?: "Canción"
                val artist = it.getString(artistCol) ?: "Artista desconocido"
                val uri = Uri.withAppendedPath(collection, id.toString())
                songs.add(Song(title, artist, uri))
            }
        }
        renderSongs()
    }

    private fun renderSongs() {
        listContainer.removeAllViews()
        if (songs.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No encontramos canciones en tu teléfono. Guardá archivos de audio en el dispositivo y volvé a abrir la app."
                textSize = 15f
                setTextColor(0xFFCDC4DB.toInt())
                setPadding(8, 24, 8, 24)
            }
            listContainer.addView(empty)
            return
        }
        songs.forEachIndexed { index, song ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 12, 12, 12)
                setBackgroundColor(if (index % 2 == 0) 0xFF191226.toInt() else 0xFF100B1D.toInt())
                setOnClickListener { playSong(index) }
            }
            val title = TextView(this).apply {
                text = song.title
                textSize = 16f
                setTextColor(0xFFFFFFFF.toInt())
            }
            val artist = TextView(this).apply {
                text = song.artist
                textSize = 13f
                setTextColor(0xFFB9A4FF.toInt())
            }
            row.addView(title)
            row.addView(artist)
            listContainer.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun playSong(index: Int) {
        val items = songs.map { song ->
            MediaItem.Builder()
                .setUri(song.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .build()
                )
                .build()
        }
        player?.let {
            it.setMediaItems(items, index, 0L)
            it.prepare()
            it.play()
            nowPlaying.text = songs[index].title
            playButton.text = "Ⅱ"
        } ?: Toast.makeText(this, "El reproductor todavía está iniciando", Toast.LENGTH_SHORT).show()
    }

    private fun togglePlayback() {
        player?.let {
            if (it.isPlaying) it.pause() else it.play()
            playButton.text = if (it.isPlaying) "Ⅱ" else "▶"
        }
    }

    private fun updatePlaybackInfo() {
        val p = player ?: return
        if (p.mediaItemCount > 0) {
            val title = p.mediaMetadata.title?.toString()
            if (!title.isNullOrBlank()) nowPlaying.text = title
            val duration = if (p.duration > 0) p.duration else 0L
            val position = p.currentPosition.coerceAtLeast(0L)
            seekBar.progress = if (duration > 0) (position * 1000 / duration).toInt() else 0
            timeText.text = "${formatTime(position)} / ${formatTime(duration)}"
            playButton.text = if (p.isPlaying) "Ⅱ" else "▶"
        }
    }

    private fun formatTime(ms: Long): String {
        val total = TimeUnit.MILLISECONDS.toSeconds(ms)
        return String.format("%d:%02d", total / 60, total % 60)
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}
